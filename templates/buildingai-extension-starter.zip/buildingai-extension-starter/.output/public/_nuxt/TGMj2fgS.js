import{i as e}from"#entry";function a(r,u="reka"){return r||`${u}-${e?.()}`}export{a as u};
