import { defineBuildingAIEslintConfig } from "@buildingai/eslint-config/nuxt";

export default await defineBuildingAIEslintConfig();
